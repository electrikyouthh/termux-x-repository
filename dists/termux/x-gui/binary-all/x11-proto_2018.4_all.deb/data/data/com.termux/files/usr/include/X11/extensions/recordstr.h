#warning "recordstr.h is obsolete and may be removed in the future."
#warning "include <X11/extensions/record.h> for the library interfaces."
#warning "include <X11/extensions/recordproto.h> for the protocol defines."
#include <X11/extensions/recordproto.h>
